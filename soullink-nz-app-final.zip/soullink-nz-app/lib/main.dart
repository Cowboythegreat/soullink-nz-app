
import 'package:flutter/material.dart';

void main() => runApp(SoulLinkApp());

class SoulLinkApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SoulLink NZ',
      theme: ThemeData.dark(),
      home: Scaffold(
        appBar: AppBar(title: Text('SoulLink New Zealand')),
        body: Center(child: Text('Welcome to SoulLink!')),
      ),
    );
  }
}
